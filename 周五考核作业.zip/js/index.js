/*轮播图开始*/

/*function Show(     )*/




var oPiont=document.getElementById('ban_point')
var aList=oPiont.getElementsByTagName("li")
var oBanner=document.getElementById('Banner')
var aBanner=oBanner.getElementsByTagName("li")
var oUp=document.getElementById("ctrl_l")
var oDown=document.getElementById("ctrl_r")
var i=0;
var j=0;
aBanner[i].style.display="block"

for(i=0;i<aList.length;i++)
{

aList[i].index=i;
aList[i].onclick=function()
{
	j=this.index
	for(i=0;i<aList.length;i++)
	{
		aList[i].className=""
		aBanner[i].style.display="none"
	}
	
		aList[this.index].className="ban_active"
		aBanner[this.index].style.display="block"
}
oDown.onclick=function()
{
	var e=j
		if(j==aBanner.length-1)
		{
			j=-1;
		}
		j=j+1;
		aBanner[e].style.display="none"
		aList[e].className=""
		aBanner[j].style.display="block"
		aList[j].className="ban_active"
}

oUp.onclick=function()
{
	var e=j
	j=j-1;
		if(j==-1)
		{
			j=aBanner.length-1;
		}
		
		aBanner[e].style.display="none"
		aList[e].className=""
		aBanner[j].style.display="block"
		aList[j].className="ban_active"
}
}

/*轮播图结束*/



/*首页导航栏开始*/
var oNav=document.getElementById("subnaver")
var aNav=oNav.getElementsByTagName("a")

var m=0


for(m=0;m<aNav.length;m++){
		aNav[m].index=m;
aNav[m].onclick=function()
{

	for(m=0;m<aNav.length;m++)
	{
		aNav[m].className=""
	}
	aNav[this.index].className="s_active"
	
}

}

/*首页导航栏结束*/

/*搜索框占位符开始*/
	var oPlaceh=document.getElementById('placeh')
	var oS=document.getElementById('search_in')
	oS.onfocus=function()
	{	
		
		oPlaceh.style.display="none"
	}
		
	oS.onblur=function()
	{	
		
		oPlaceh.style.display="block"
	}
/*搜索框占位符结束*/
